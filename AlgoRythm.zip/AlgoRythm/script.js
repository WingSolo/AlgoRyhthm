document.addEventListener('DOMContentLoaded', function() {
    const loginToggle = document.getElementById('login-toggle');
    const loginForm = document.getElementById('login-form');
    const mainContent = document.getElementById('main-content');
    const noticeBoard = document.getElementById('notice-board');
    const analysisLink = document.getElementById('analysis-link');
    const analysisSection = document.getElementById('analysis-section');

    if (loginToggle) {
        loginToggle.addEventListener('click', function(event) {
            event.preventDefault(); // 링크 기본 동작 방지
            // 로그인 폼 표시
            loginForm.style.display = 'block';
            // 본문과 공지사항 숨기기
            mainContent.style.display = 'none';
            noticeBoard.style.display = 'none';
            analysisSection.style.display = 'none';
        });
    }

    if (analysisLink) {
        analysisLink.addEventListener('click', function(event) {
            event.preventDefault(); // 링크 기본 동작 방지
            // 분석사례 섹션 표시
            mainContent.style.display = 'none';
            noticeBoard.style.display = 'none';
            loginForm.style.display = 'none';
            analysisSection.style.display = 'block';
        });
    }

    // 로그인 폼의 로그인 버튼 클릭 시 처리
    const loginButton = loginForm ? loginForm.querySelector('button[type="submit"]') : null;
    if (loginButton) {
        loginButton.addEventListener('click', function(event) {
            event.preventDefault();
            // 로그인 처리 코드 추가
            alert('로그인 버튼 클릭됨');
        });
    }

    // 로그인 폼의 회원가입 버튼 클릭 시 처리
    const signupButton = document.getElementById('signup-btn');
    if (signupButton) {
        signupButton.addEventListener('click', function() {
            // 회원가입 처리 코드 추가
            alert('회원가입 버튼 클릭됨');
        });
    }

    // 로고와 홈 버튼 클릭 시 페이지 새로 고침
    const logoLink = document.getElementById('logo-link');
    const homeLink = document.getElementById('home-link');
    
    if (logoLink) {
        logoLink.addEventListener('click', function(event) {
            event.preventDefault(); // 링크 기본 동작 방지
            location.reload(); // 페이지 새로 고침
        });
    }
    
    if (homeLink) {
        homeLink.addEventListener('click', function(event) {
            event.preventDefault(); // 링크 기본 동작 방지
            location.reload(); // 페이지 새로 고침
        });
    }
});
